mynameiszzr_noharm.php => 
/../nt1/zzr_noharm.php