<?php
dl('zip.so');
unlink("test1.zip");
$zip = new Zip();
$zip->open("test1.zip");
$zip->addFromString("testfilephp.txt" . time(), "#1 This is a test string added as testfilephp.txt.\n");
$zip->addFromString("testfilephp2.txt" . time(), "#2 This is a test string added as testfilephp2.txt.\n");
$zip->addFile("too.php", "testfromfile.php");
echo $zip->numFiles() . "\n";
print_r($zip->status());
//echo $zip->status;
