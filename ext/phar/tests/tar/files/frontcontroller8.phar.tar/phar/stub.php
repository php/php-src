<?php
Phar::webPhar("whatever", "index.php", null, array("jpg" => "foo/bar", "phps" => Phar::PHP, "php" => Phar::PHPS));
echo "oops did not run\n";
var_dump($_ENV, $_SERVER);
__HALT_COMPILER(); ?>
