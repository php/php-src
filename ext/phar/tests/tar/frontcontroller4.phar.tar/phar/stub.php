<?php
function s($a)
{
    static $b = array("/hi" => false);
    if (isset($b[$a])) return $b[$a];
    return $a;
}
Phar::webPhar("whatever", "index.php", null, array(), "s");
echo "oops did not run\n";
var_dump($_ENV, $_SERVER);
__HALT_COMPILER(); ?>
