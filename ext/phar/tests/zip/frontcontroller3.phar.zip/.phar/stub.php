<?php
function s($a)
{
    static $b = array("/hi" => "a.phps");
    if (isset($b[$a])) return $b[$a];
}
Phar::webPhar("whatever", "/index.php", null, array(), "s");
echo "oops did not run\n";
var_dump($_ENV, $_SERVER);
__HALT_COMPILER(); ?>
