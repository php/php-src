<?php
Phar::webPhar("whatever", "index.php", null, array(), array("/hi" => "a.phps"));
echo "oops did not run\n";
var_dump($_ENV, $_SERVER);
__HALT_COMPILER();