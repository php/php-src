<?php
Phar::webPhar("whatever", "a.php");
echo "oops did not run\n";
var_dump($_ENV, $_SERVER);
__HALT_COMPILER();