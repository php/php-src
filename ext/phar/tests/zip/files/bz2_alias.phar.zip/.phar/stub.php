<?php
echo "hi';
__HALT_COMPILER();
?>
